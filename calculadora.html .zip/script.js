function pegarDados(){
  let f1 = document.getElementById("f1").value;
  let f2 = document.getElementById("f2").value;
  let f3 = document.getElementById("f3").value;
  let mult = document.getElementById("mult").value;
  let tl = document.getElementById("tl").value;
  
  let concatenar = parseFloat(f1 + f2 + f3);
  let result = concatenar * mult;
  let tl1 = result * tl;
  let tl2 = result - tl1;
  let tl3 = result + tl1;
  
  document.getElementById('result').innerHTML = result + ' ohms com tolerância mínima de ' + tl2 + ' ohms e máxima ' + tl3 + ' ohms ';
}